<?php
/** LISTA BLANCA DE RUTAS: solo las URLs registradas aquí son accesibles */

use Controllers\LibroController;
use Core\Pages;
use Core\Router;

return [
    // ... tus rutas actuales ...

    // Carrito
    'GET /carrito'          => ['CarritoController', 'index'],      // Formulario
    'POST /carrito/anadir'  => ['CarritoController', 'anadir'],     // Añadir producto
    'GET /carrito/pedidos'  => ['CarritoController', 'pedidos'],    // Ver cesta
];

Router::add('get', '/', [CarritoController::class, 'index']);

Router::add('post', 'carrito/anadir', [CarritoController::class, 'anadir']);

Router::add('get', 'carrito/pedidos', [CarritoController::class, 'pedidos']);