
<h1>El contenido de la cesta de la compra es:</h1>

<?php if (empty($cesta)): ?>
    <p>La cesta está vacía.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Artículo</th>
                <th>Cantidad</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cesta as $articulo => $cantidad): ?>
                <tr>
                    <td><?= htmlspecialchars($articulo) ?></td>
                    <td><?= $cantidad ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<br>
<a href="/carrito">← Volver al carrito</a>