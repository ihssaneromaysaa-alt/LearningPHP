<h1 style="background:yellow; text-align:center;">Carrito de la compra</h1>
<h2>Introduce los productos que deseas comprar</h2>

<form action="/carrito/anadir" method="post">
    <label>
        Dime el producto
        <input type="text" name="producto" required>
    </label>
    <br><br>

    <label>
        Cuántas unidades
        <select name="cantidad">
            <?php for ($i = 1; $i <= 10; $i++): ?>
                <option value="<?= $i ?>"><?= $i ?></option>
            <?php endfor; ?>
        </select>
    </label>
    <br><br>

    <button type="submit">Añadir a la cesta</button>
    <a href="/carrito/pedidos">
        <button type="button">Comprar</button>
    </a>
</form>